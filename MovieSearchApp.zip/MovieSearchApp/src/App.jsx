import './App.css';
import {BrowserRouter, Routes, Route } from 'react-router-dom';
import MovieSearchPage from './pages/Moviesearchpage';
import MovieDetailsPage from './pages/Moviedetailspage';
import Home from './pages/Home';
function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path='/MovieSearchApp' element={<Home />} />
          <Route path='/MovieSearchApp/MovieSearchPage' element={<MovieSearchPage />} />
          <Route path='/MovieSearchApp/MovieDetailspage/:moviename' element={<MovieDetailsPage />} />
        </Routes>
      </BrowserRouter>
    </>
  )
}

export default App
